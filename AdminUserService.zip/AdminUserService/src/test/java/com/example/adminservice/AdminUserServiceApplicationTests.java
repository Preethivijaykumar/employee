package com.example.adminservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
