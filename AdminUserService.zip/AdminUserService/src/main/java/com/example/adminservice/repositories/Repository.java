package com.example.adminservice.repositories;

import org.springframework.data.repository.CrudRepository;

import com.example.adminservice.entities.Admin;

public interface Repository extends CrudRepository<Admin, String>{

}
