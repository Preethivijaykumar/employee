package com.example.adminservice.service;

import org.springframework.stereotype.Service;

import com.example.adminservice.models.Request;

@Service
public class AdminServiceImpl implements AdminService{

	@Override
	public String test() {
		return null;
	}

	@Override
	public Boolean verifyCredentials(Request request) {
		return null;
	}

}
