package com.example.adminservice.service;

import com.example.adminservice.models.Request;

public interface AdminService {

	public String test();
	
	public Boolean verifyCredentials(Request request);
	
}
