package com.example.adminservice.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Entity
public class Admin {
	
	@Id
	private String uname;
	
	@Column(nullable = false)
	private String password;
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		password = (new BCryptPasswordEncoder()).encode(password);
		this.password = password;
	}
	@Override
	public String toString() {
		return "Admin [uname=" + uname + ", password=" + password + "]";
	}
	
	public Admin() {
		
	}
	public Admin(String uname, String password) {
		super();
		this.uname = uname;
		this.password = password;
	}

	
}
