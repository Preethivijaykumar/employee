package com.example.adminservice.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.adminservice.entities.Admin;
import com.example.adminservice.models.Request;
import com.example.adminservice.repositories.Repository;

@RestController
//@RequestMapping("/")
public class AdminController {
	
	@Autowired
	Repository repo;
	
	
	@GetMapping("/")
	public String test() {
		System.out.println("executed");
		return "test";
	}
	
	@PostMapping("/verify")
	public Boolean verifyCredentials(@RequestBody Request request) {
		Admin admin =  new Admin();
		admin.setPassword("test");
		admin.setUname("test");
		System.out.println(admin.getPassword());
		System.out.println(request.getPassword());
		return BCrypt.checkpw(request.getPassword(), admin.getPassword());
	}
	
	
	

}
